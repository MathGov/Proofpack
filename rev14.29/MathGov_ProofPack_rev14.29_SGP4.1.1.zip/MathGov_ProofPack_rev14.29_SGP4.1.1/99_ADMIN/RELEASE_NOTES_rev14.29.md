# Release Notes (rev14.29)

- Canonical tuple updated for SGP 4.1.1.
- Legacy MIT-4/MI references labeled deprecated.
