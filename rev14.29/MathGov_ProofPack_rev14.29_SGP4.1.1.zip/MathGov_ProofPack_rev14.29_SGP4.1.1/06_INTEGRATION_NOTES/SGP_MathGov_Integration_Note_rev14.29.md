# SGP–MathGov Integration Note (rev14.29)

SGP 4.1.1 is normative for sentience and moral-status evaluation. The Foundation paper defers to SGP; Appendices contain Appendix G mapping tiers to rights handling.
