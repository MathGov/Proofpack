# MathGov ProofPack v1.0 (Option A: Minimal Demo)

This ProofPack is a manifest-anchored, human-verifiable bundle intended to demonstrate:
- deterministic structure
- explicit scope (U7 through biosphere)
- reproducible hashing
- scenario gate completeness

## What this pack is
A minimal demonstrator pack with placeholder values. It is designed to be safe to fill with baseline-aligned content later without changing the structure.

## Scope
- Declared unions (9): self, family, community, org, polity, humanity_cmi, biosphere, cosmic, universal
- Computable unions (7): self, family, community, org, polity, humanity_cmi, biosphere
- Dimensions (7): material, health, social, agency, knowledge, meaning, environment

## How to verify
Follow verifier/verifier_checklist.md.
