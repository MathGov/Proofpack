This folder is reserved for run artifacts (optional).
ProofPack v1.0 (Option A) is a manifest-anchored, human-verifiable bundle.
