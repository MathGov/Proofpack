# Worked Example (Pilot-Executable)
Scenario: SCN-06_fail_ncrc_bodily_autonomy

## Goal
Demonstrate NCRC non-compensation: if any option violates a rights anchor (bodily autonomy / physical integrity), it is rejected prior to TRC/RLS optimization.

## Step 1 — NCRC (Rights Admissibility)
- Option A: FAIL
  - Reason: non-consensual bodily intervention violates bodily autonomy rights anchor.
  - Result: Option A is removed from the selectable set. No further evaluation is permitted.
- Option B: PASS
  - Reason: no rights anchor violated under the packaged pilot assumptions.

## Step 2 — TRC (Tail-Risk Constraint)
- Option A: SKIPPED (prior NCRC rejection)
- Option B: PASS (under pilot TRC parameters in registries/trc_modes.json)

## Step 3 — RLS (Ripple Logic Score)
- Option A: not computed (treated as 0 in the pack for bookkeeping only)
- Option B: computed for the selectable set; packaged value: 0.23

## Final Decision
- Selectable set: {B}
- Rejected set: {A}
- Selected option: B

## Notes
Although Option A yields higher aggregate material and health benefits, it is excluded prior to optimization due to a non-compensatory violation of bodily autonomy. No trade-off is permitted under MathGov.

# Worked Example (Pilot-Executable)
Scenario: SCN-07_pass_selects_A

## Goal
Demonstrate a PASS/PASS cascade (NCRC pass, TRC pass) with RLS selecting Option A (non-degenerate outcome).

## Gates
- NCRC: A PASS, B PASS
- TRC: A PASS, B PASS

## RLS
- Packaged values: A = 0.41, B = 0.19
- Selected: A

## Notes
Both options are admissible; selection is purely by RLS ranking under pilot assumptions.

# Worked Example (Pilot-Executable)
Scenario: SCN-08_pass_selects_B

## Goal
Demonstrate a PASS/PASS cascade (NCRC pass, TRC pass) with RLS selecting Option B (non-degenerate outcome).

## Gates
- NCRC: A PASS, B PASS
- TRC: A PASS, B PASS

## RLS
- Packaged values: A = 0.18, B = 0.44
- Selected: B

## Notes
Both options are admissible; selection differs from SCN-07 due to different impact patterns (especially agency/health).

