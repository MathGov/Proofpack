# ProofPack v1.0 Verifier Checklist (Human Steps Only)

Scope: This ProofPack is **U7-scored** (through biosphere). Cosmic and universal are declared but noncomputable in v1.0.

## 1) Verify file tree
Confirm the ProofPack contains these top-level items:
- manifest.json
- hashes/
- registries/
- scenarios/
- verifier/
- conformance/
- README.md

## 2) Verify hashes
Open:
- hashes/manifest.sha256
- hashes/registries.sha256
- hashes/scenarios.sha256
- hashes/proofpack.sha256

Recompute sha256 for each referenced file and confirm exact matches.

## 3) Verify manifest bindings
Open manifest.json and confirm:
- declared_unions lists 9 unions
- computable_unions lists 7 unions (through biosphere)
- defaults.trc_mode_id exists in registries/trc_modes.json
- registries filenames and hashes match hashes/registries.sha256
- scenario filenames and hashes match hashes/scenarios.sha256

## 4) Verify scenario gate completeness
For each scenario file in scenarios/:
Confirm it contains:
- rights_screen results for each option
- trc_screen results for each option
- containment_safeguards results for each option
- rls scores and ranking
- decision selected option

## 5) Compare to expected outputs
Open verifier/expected_outputs.json and confirm the scenario pass/fail and selections match the scenario files.

If any mismatch is found, ProofPack v1.0 does not conform.
