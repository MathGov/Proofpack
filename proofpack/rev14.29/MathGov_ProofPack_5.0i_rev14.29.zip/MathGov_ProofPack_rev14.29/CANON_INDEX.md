# Canon Index (rev14.29)

Start here:

1) **Foundation Paper**
   - `CANON/MathGov_Foundation_5.0i_rev14.29_FINAL_SYNCED.docx`

2) **Appendices**
   - `CANON/MathGov_Appendices_5.0i_rev14.29_FINAL_SYNCED.docx`

3) **Sentience Gradient Protocol (SGP 4.1.1)**
   - `CANON/SGP_4.1.1_PATCHED_READY_PUBLISH.docx`

Supporting:
- `SUPPORT/Alignment_Constitution_Public.pdf`
- `SUPPORT/Alignment_Test_Case_Library.pdf`
