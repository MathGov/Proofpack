# MathGov ProofPack — 5.0i rev14.29

This ProofPack is the verification bundle for the MathGov canonical release **5.0i rev14.29**.

## Canonical documents (normative)
- `CANON/MathGov_Foundation_5.0i_rev14.29_FINAL_SYNCED.docx`
- `CANON/MathGov_Appendices_5.0i_rev14.29_FINAL_SYNCED.docx`
- `CANON/SGP_4.1.1_PATCHED_READY_PUBLISH.docx`

## Supporting documents
- `SUPPORT/Alignment_Constitution_Public.pdf`
- `SUPPORT/Alignment_Test_Case_Library.pdf`
- `SUPPORT/Rev14.29_Audit_Report_CP.docx`

## Integrity verification (SHA-256)
This ProofPack includes:
- `SHA256SUMS.txt` — SHA-256 hashes for every file in the bundle
- `manifest.json` — machine-readable list of files + hashes + metadata

### Verify with SHA-256
**Mac/Linux**
```bash
shasum -a 256 -c SHA256SUMS.txt
```

**Windows PowerShell**
```powershell
Get-FileHash -Algorithm SHA256 .\CANON\MathGov_Foundation_5.0i_rev14.29_FINAL_SYNCED.docx
Get-FileHash -Algorithm SHA256 .\CANON\MathGov_Appendices_5.0i_rev14.29_FINAL_SYNCED.docx
Get-FileHash -Algorithm SHA256 .\CANON\SGP_4.1.1_PATCHED_READY_PUBLISH.docx
```
Compare the outputs to `SHA256SUMS.txt`.

## Notes
- The Foundation Paper binds sentience classification to **SGP 4.1.1** and Appendix G.
- Appendix G defines the canonical scalar mapping:
  - `SGP_score(E) := min(A(E), B(E), C(E))`
  - `SG_norm(E) := SGP_score(E)/100`
  - `s_k := SG_norm(E)`
  - Human plateau rule: `SG_norm(H) := 1.0`
